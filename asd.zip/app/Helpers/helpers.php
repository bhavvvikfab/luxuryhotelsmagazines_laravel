<?php 

// helpers.php

if (!function_exists('exampleHelper')) {
    function exampleHelper()
    {
        return 'This is an example helper function.';
    }

    function paypalSubscription(){
        return 'This is an example helper function.';
    }
}
